


<?php

  session_start();

$saller_login = $_SESSION['login'];
$ware_name = $_POST['ware_name'];
$ware_type = $_POST['ware_type'];
$cost = $_POST['cost'];
$ware_img = $_POST['ware_img'];
$description = $_POST['description'];


include ("dbconnect.php");


$result2 = $mysqli -> query ("INSERT INTO wares (saller_login,ware_name,ware_type,description,cost,ware_img) VALUES ('$saller_login' , '$ware_name' , '$ware_type', '$description', '$cost','$ware_img' )") ;

if ($result2 == 'TRUE') {

ob_start();
$new_url = 'cabinet.php';
header('Location: '.$new_url);
ob_end_flush();

}

else {
echo '<script language="javascript">';	
echo 'alert("Ошибка создания лота")';
echo '</script>';


}

?>
