<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Товар</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>





<div class="loginregister"> 
<?php 

$login = @ $_SESSION['login'];
if (empty($_SESSION['login']))

{

 ?>

<a href="login.php"><div class="loginbutton"> Авторизироваться <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}
else {

 ?>

<a href="cabinet.php"><div class="loginbutton"> Личный кабинет <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}

 ?>

</div>

</header>

<?php 

$id = $_GET["id"];

include("dbconnect.php");
$result = $mysqli -> query ("SELECT * FROM wares  WHERE ware_id = '$id' ");
$data = $result->fetch_assoc();

$saller = $data['saller_login'];

$result2 = $mysqli -> query ("SELECT * FROM users  WHERE login = '$saller' ");
$data2 = $result2->fetch_assoc();



 ?>




<div class="bigwarewindow">
	
<div class="wareinfowindow">
	<h1> <?php echo $data['ware_name']; ?> </h1>

	<div class="smallwarewindow">

	<div class="imgwindow">

		<?php 

error_reporting(E_ERROR);

include("dbconnect.php");
$result = $mysqli -> query ("SELECT * FROM wares WHERE ware_id = '$id' ");
while ($myrow = $result -> fetch_assoc())
{


			if(exif_imagetype($myrow["ware_img"])) {
				echo '<img src = '.$myrow["ware_img"].' > ';
			}
			else
			{
			echo ' <img src = "img/missingimg.svg"  > ';
			}
			
}



		?>
	</div>

	<div class="buytower">
		<form action="buyware.php">
			<h2> <?php echo $data['cost']; ?> Руб. </h2>
			<hr class="line">
			<h2> <?php echo $data['ware_type']; ?> </h2>
			<hr class="line">

			<div class="radios">
<div>
			<input type="radio" id="Почта" name="arrrivalmetod" value="Почта России" checked />
			<label for="Почта">Почта России</label>
</div>
<div>
			<input type="radio" id="СДЭК" name="arrrivalmetod" value="СДЭК"  />
			<label for="СДЭК">СДЭК</label>
</div>
<div>
			<input type="radio" id="Самовывоз" name="arrrivalmetod" value="Самовывоз"  />
			<label for="Самовывоз">Самовывоз</label>
</div>
<input type="submit" name="submit" value="Купить" class="buybutton" >
			</div>
		</form>
	</div>
</div>
<div class="descriptionwindow">
	<?php echo" Описание - ". $data['description']; ?>
</div>

</div>




<div class="sellerinfowindow">
	
	<img src="img/person.png">
	<h1> <?php echo $data2['fullname']; ?> </h1>
	<p>
	<h3 style="margin-top: -20px;"> <?php echo $data2['address']; ?> </h3>
	</p>

<p class="commentsection">

<?php 

$result3 = $mysqli -> query ("SELECT * FROM remarks WHERE saller_login = '$saller' order by comment_time DESC ");
$data3 = $result3->fetch_assoc();

if ($data3['commenter_login'] != null)
{

echo 
"
<div class='comment'>
<p> ".$data3['commenter_login']." </p>

".$data3['comment_text']."
</div>
";
}
else { echo "Нет комментариев";}



 ?>

</p>

<div class="commentbutton">
<?php  
echo "

<a href='commentlist.php?saller=$saller'> Комментарии </a>


";
?>
</div>






</div>

</div>

</body>
</html>