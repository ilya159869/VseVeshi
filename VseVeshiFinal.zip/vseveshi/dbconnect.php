
<?php 
$mysqli = new mysqli ('localhost','root','','VseVeshiDB');
if ($mysqli -> connect_error)
{
die('Connect Error ('.$mysqli ->connecterrno.')'.$mysqli -> connect_error);
}

 ?>
