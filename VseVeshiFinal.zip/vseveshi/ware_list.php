<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Поиск по типу товара</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>





<div class="loginregister"> 
<?php 

$login = @ $_SESSION['login'];
if (empty($_SESSION['login']))

{

 ?>

<a href="login.php"><div class="loginbutton"> Авторизироваться <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}
else {

 ?>

<a href="cabinet.php"><div class="loginbutton"> Личный кабинет <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}

 ?>

</div>

</header>


<?php 
$waretype = $_GET["waretype"];

echo "<h1>".$waretype."</h1>";

 ?>
<p></p>

<div class="wares">


<?php

error_reporting(E_ERROR);

$waretype = $_GET["waretype"];



include("dbconnect.php");
$result = $mysqli -> query ("SELECT * FROM wares WHERE ware_type = '$waretype' ");

$div = '<div class = "warebox">';
$k = 1;
while ($myrow = $result -> fetch_assoc())
{
	$testempty=1;

	$div .= '<div class="ware">';
	
$id = $myrow["ware_id"];
		$div .="<a href=warebuy.php?id=$id>";
			


			if(exif_imagetype($myrow["ware_img"])) {
			$div .='<img src = '.$myrow["ware_img"].'  >';
			}
			else
			$div .='<img src = "img/missingimg.svg"  >';
			



			$div .= "<p>".$myrow["ware_name"].'</p>';	
			$div .='
				
				<div class="tinywarebox">  
				<div class="waretype"> '.$myrow["ware_type"].'	</div>

				<div class="warecost">	'.$myrow["cost"].' руб. </div>

			   </div>';

				$div .="</a>";

		$div .='</div>';
		$k++;
}
$div .='</div>';
echo $div;

if ($testempty == 0) {
	echo "<h1 class='emptymessage'> Нет активных лотов.</h1>";
}


?>



</div>














</body>
</html>
