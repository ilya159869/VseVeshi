<?php

session_start();

include ("dbconnect.php");

 $id=$_POST['ware_id'];

$mysqli -> query("DELETE FROM wares WHERE ware_id = $id ");
 
ob_start();
$new_url = 'cabinet.php';
header('Location: '.$new_url);
ob_end_flush();

?>