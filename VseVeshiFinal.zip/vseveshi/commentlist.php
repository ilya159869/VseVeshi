<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Товар</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>





<div class="loginregister"> 
<?php 

$login = @ $_SESSION['login'];
if (empty($_SESSION['login']))

{

 ?>

<a href="login.php"><div class="loginbutton"> Авторизироваться <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}
else {

 ?>

<a href="cabinet.php"><div class="loginbutton"> Личный кабинет <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}

 ?>

</div>

</header>

<?php 


include("dbconnect.php");


$saller = $_GET["saller"];

$result2 = $mysqli -> query ("SELECT * FROM users  WHERE login = '$saller' ");
$data2 = $result2->fetch_assoc();

$result3 = $mysqli -> query ("SELECT * FROM remarks  WHERE saller_login = '$saller' ");
$data3 = $result3->fetch_assoc();

$_SESSION['saller_login'] = $saller;



 ?>



<div class="bigwarewindow">
	
<div class="commentwindow">

<?php 

if (!empty($_SESSION['login']) )
{

	if ($_SESSION['login'] != $saller) {

		echo 
		"
<div class='commentform'>

<form action='savecomment.php' method='post'>
	
<input type='text' name='comment_text' class='inputbar3' placeholder='Текст комментария...'' required>
<input type='submit' name='submit' value='Создать комментарий'' class='submitcommentbutton'>

</form>

</div>



		";

	}
}

 ?>



<div class="commentlistall" style="overflow-y:scroll;">
	
<?php 

$result3 = $mysqli -> query ("SELECT * FROM remarks WHERE saller_login = '$saller' order by comment_time DESC ");

while ($data3 = $result3->fetch_assoc()) {

if ($data3['commenter_login'] != null)
{

echo 
"
<div class='comment'>
<p><img src='img/person.png'> ".$data3['commenter_login']." </p>

".$data3['comment_text']."
</div>
";
}
else { echo "Нет комментариев";}

}


 ?>






</div>


</div>




<div class="sellerinfowindow">
	
	<img src="img/person.png">
	<h1> <?php echo $data2['fullname']; ?> </h1>
	<p>
	<h3 style="margin-top: -20px;"> <?php echo $data2['address']; ?> </h3>
	</p>

<p class="commentsection">

<?php 

error_reporting(E_ERROR);

$result3 = $mysqli -> query ("SELECT * FROM remarks WHERE saller_login = '$saller' order by comment_time DESC ");
$data3 = $result3->fetch_assoc();

if ($data3['commenter_login'] != null)
{

echo 
"
<div class='comment'>
".$data3['commenter_login']."
<hr class='line'>
".$data3['comment_text']."
</div>
";

}

else echo "Нет комментариев";

 ?>




</p>







</div>

</div>

</body>
</html>