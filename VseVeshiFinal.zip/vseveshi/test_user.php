<?php

session_start();

if (isset($_POST['login'])) {
	$login = $_POST['login'];
	if ($login =='') {
		unset($login);
	}
}

if (isset($_POST['password'])) {
	$password = $_POST['password'];
	if ($password =='') {
		unset($password);
	}
}

if (empty ($login) or empty ($password)) {
	exit ("не заполнены все поля");
}

include ("dbconnect.php");

$result = $mysqli -> query("SELECT * FROM users WHERE login = '$login' ");

$myrow = $result->fetch_assoc();

if (empty($myrow['login'])) {

ob_start();
$new_url = 'index.php';
header('Location: '.$new_url);
ob_end_flush();

	exit ("неправильный ввод");

	
}
else {
	if ($myrow['password'] == $password){
		$_SESSION ['login'] = $myrow['login'];
		$_SESSION ['id'] = $myrow['user_id'];

ob_start();
$new_url = 'index.php';
header('Location: '.$new_url);
ob_end_flush();

		$_SESSION ['login'] = $login;
	}
	else {

echo '<script language="javascript">';	
echo 'alert("Неправильно введён логин или пароль")';
echo '</script>';

	}
}


?>



