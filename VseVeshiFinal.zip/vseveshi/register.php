<!DOCTYPE html>
<html>
<head>
	<title> Регистрация </title>
<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body style="font-family: Jura; align-content: center;">


<?php 
session_start();
 ?>


<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>

</header>


<div class="loginbox" style="height: 580px;">
	
<h1> Регистрация </h1>
<p></p>

	
<form action="save_user.php" method="post">

	<p>

		<input type="text" name="login" class="inputbar" placeholder="Логин..." minlength="6" required>
	</p>

	<p>
		<input type="text" name="password" class="inputbar" placeholder="Пароль..." minlength="8" required>
	</p>

	<p>
		<input type="email" name="email" class="inputbar" placeholder="Почта..." required>
	</p>

	<p>
		<input type="text" name="address" class="inputbar" placeholder="Адрес..." required>
	</p>

	<p>
		<input type="text" name="fullname" class="inputbar" placeholder="Полное имя..."minlength="12" required>
	</p>


	<p>
		<input type="tel" name="phone" class="inputbar" placeholder="Телефонный номер..." required minlength="11" maxlength="11">
	</p>

<p>
	<input type="submit" name="submit" value="Регистрация" class="bigbutton" style="width: 240px;">
</p>

</form>

<a href="login.php" style="font-size: 30px;"> Уже есть аккаунт ?</a>



</div>



</body>
</html>