<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Создание лота на продажу</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>


<div class="loginregister"> 
<a href="exit.php"><div class="loginbutton"> Выйти из аккаунта <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>
</div>

</header>


<div> <h2>Создание лота на продажу - </h2> </div>

<div class="formlot">

<form action="save_lot.php" method="post">

	<p>

		<input type="text" name="ware_name" class="inputbar2" placeholder="Название товара..." required>
	</p>

<p>
<nav role="navigation" class="primary-navigation" >
  <ul>

    <li><a href="#">Тип товара &dtrif;</a>
      <ul class="dropdown">

        <li class="dropli"><input type="radio" id="Одежда" name="ware_type" value="Одежда" checked  />
    <label for="Одежда">Одежда</label></li>

        <li class="dropli">  <input type="radio" id="Товары для хобби" name="ware_type" value="Товары для хобби" />
    <label for="Товары для хобби">Товары для хобби</label></li>

        <li class="dropli">  <input type="radio" id="Литература" name="ware_type" value="Литература" />
    <label for="Литература">Литература</label></li>

        <li class="dropli">  <input type="radio" id="Техника" name="ware_type" value="Техника" />
    <label for="Техника">Техника</label></li>

        <li class="dropli">  <input type="radio" id="Игры и консоли" name="ware_type" value="Игры и консоли" />
    <label for="Игры и консоли">Игры и консоли</label></li>

            <li class="dropli">  <input type="radio" id="Аксесуары" name="ware_type" value="Аксесуары" />
    <label for="Аксесуары">Аксесуары</label></li>

        <li class="dropli">  <input type="radio" id="Другое" name="ware_type" value="Другое" />
    <label for="Другое">Другое</label></li>


      </ul>
    </li>
  </ul>
</nav>
</p>

	<p>
		<input type="text" name="cost" class="inputbar2" placeholder="Цена..." required>
	</p>

	<p>
		<input type="text" name="ware_img" class="inputbar2" placeholder="URL изображения товара..." required>
	</p>

	<p>
		<input type="text" name="description" class="inputbar2" placeholder="Описание..." required>
	</p>


<p>
	<input type="submit" name="submit" value="Создать лот" class="bigbutton">
</p>

</form>

</div>






</body>
</html>