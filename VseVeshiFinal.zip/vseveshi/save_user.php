


<?php


session_start();

if (isset($_POST['login'])) {
	$login = $_POST['login'];
	if ($login == '') {
		unset($login);
	}
}

if (isset($_POST['password'])) {
	$password = $_POST['password'];
	if ($password == '') {
		unset($password);
	}
}

if (isset($_POST['email'])) {
	$email = $_POST['email'];
	if ($email == '') {
		unset($email);
	}
}

if (isset($_POST['address'])) {
	$address = $_POST['address'];
	if ($address == '') {
		unset($address);
	}
}

if (isset($_POST['fullname'])) {
	$fullname = $_POST['fullname'];
	if ($fullname == '') {
		unset($fullname);
	}
}


if (isset($_POST['phone'])) {
	$phone = $_POST['phone'];
	if ($phone == '') {
		unset($phone);
	}
}


if(empty($login) or empty($password) or empty($email) or empty($address) or empty($fullname) or empty($phone) )
{
exit("вы не заполнили все поля");
}

include ("dbconnect.php");


$result = $mysqli -> query ("SELECT ID FROM users WHERE login = '$login' ");


$result2 = $mysqli -> query ("INSERT INTO users (login,password,email,address,fullname,phone) VALUES ('$login' , '$password' , '$email', '$address', '$fullname','$phone' )") ;

if ($result2 == 'TRUE') {

		$_SESSION ['login'] = $login;

ob_start();
$new_url = 'index.php';
header('Location: '.$new_url);
ob_end_flush();


}

else {
echo '<script language="javascript">';	
echo 'alert("Ошибка регистрации, данные уже используються или неправильные")';
echo '</script>';


}

?>
