<?php 
session_start();

$commenter_login = $_SESSION['login'];
$saller_login = $_SESSION['saller_login'] ;
$comment_text = $_POST['comment_text'];

include ("dbconnect.php");


$result2 = $mysqli -> query ("INSERT INTO remarks (commenter_login,saller_login,comment_text) VALUES ('$commenter_login' , '$saller_login' , '$comment_text' )") ;

if ($result2 == 'TRUE') {

ob_start();
$new_url = "commentlist.php?saller=$saller_login";
header('Location: '.$new_url);
ob_end_flush();

}

else {
echo '<script language="javascript">';	
echo 'alert("Ошибка создания комментария")';
echo '</script>';


}





 ?>