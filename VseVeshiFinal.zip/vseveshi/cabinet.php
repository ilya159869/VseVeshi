<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Личный кабинет</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>





<div class="loginregister"> 
<a href="exit.php"><div class="loginbutton"> Выйти из аккаунта <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>
</div>

</header>


<div style=" justify-content: space-between; display: flex; ">
	
<div> <h2>Активные лоты пользователя <?php echo $_SESSION['login'] ?> : </h2> </div>

<a href="createlot.php"><div class="loginbutton" style="margin-top: 20px;">  Создать лот  </div></a>

</div>

<div class="lots">

<?php
include("dbconnect.php");

$saller_login = $_SESSION['login'];

$sql = $mysqli -> query ("SELECT * FROM wares WHERE saller_login ='$saller_login' ");



$k = 1;

if ($sql->num_rows== 0) {
echo "<h1 class='emptymessage'> Нет активных лотов.</h1>";
}
else{

echo "<table class = 'row' ";

 while ($result = mysqli_fetch_array($sql)){

    echo "

<tr>

     <th class='tableblock'><div class='lotbox'> {$result['ware_name']} </div></th>


     <th class='tableblock'><div class='lotbox'> {$result['ware_type']} </div></th>


     <th class='tableblock'><div class='lotbox'>{$result['cost']} рублей </div></th>

    <th><form action='remove_lot.php' method='post' class='lotbox'>
                        <input type='hidden' name='ware_id' value='" . $result["ware_id"] . "' />
                            <button type='submit' class='xbutton'>
                            <img src='img/xbutton.svg' alt='Удалить' style='height: 50px;'>
                            </button>


                </form></th>
                </tr>


     ";




		$k++;
}

echo "</table>";
}


?>
</div>









</body>
</html>
