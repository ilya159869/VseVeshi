<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
	<title>Главная страница</title>
<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>



<body style="font-family: Jura;">

<?php 
session_start();

 ?>

<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>





<div class="loginregister"> 
<?php 

$login = @ $_SESSION['login'];
if (empty($_SESSION['login']))

{

 ?>

<a href="login.php"><div class="loginbutton"> Авторизироваться <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}
else {

 ?>

<a href="cabinet.php"><div class="loginbutton"> Личный кабинет <img src="img/login2.svg" style="height: 25px; margin-bottom: -5px;"> </div></a>

<?php 
}

 ?>

</div>

</header>

<div class="searchnav"> 

<div class="dropdown">
  <button class="dropbtn">Категории товаров</button>
  <div class="dropdown-content">

    <a href="ware_list.php?waretype=Одежда">Одежда</a>
    <a href="ware_list.php?waretype=Товары для хобби">Товары для хобби</a>
    <a href="ware_list.php?waretype=Литература">Литература</a>
    <a href="ware_list.php?waretype=Техника">Техника</a>
    <a href="ware_list.php?waretype=Игры и консоли">Игры и консоли</a>
    <a href="ware_list.php?waretype=Аксесуары">Аксесуары</a>
    <a href="ware_list.php?waretype=Другое">Другое</a>






  </div>
</div>

<div  class="searchbag">
<form class="searchform" action="search_lot.php" method="post">
	
<input type="text" name="warename" class="searchpad" placeholder="Введите название товара..." required>
<input type="submit" name="submit" value="Поиск" class="searchbutton" >
</form>
</div>

</div>


<div class="wares">


<?php

error_reporting(E_ERROR);

include("dbconnect.php");
$result = $mysqli -> query ("SELECT * FROM wares order by Upload_time DESC");
$div = '<div class = "warebox">';
$k = 1;
while ($myrow = $result -> fetch_assoc())
{

	$div .= '<div class="ware">';

$id = $myrow["ware_id"];
		$div .="<a href=warebuy.php?id=$id>";
			


			if(exif_imagetype($myrow["ware_img"])) {
			$div .='<img src = '.$myrow["ware_img"].'  >';
			}
			else
			$div .='<img src = "img/missingimg.svg"  >';
			



			$div .= "<p>".$myrow["ware_name"].'</p>';	
			$div .='
				
				<div class="tinywarebox">  
				<div class="waretype"> '.$myrow["ware_type"].'	</div>

				<div class="warecost">	'.$myrow["cost"].' руб. </div>

			   </div>';

				$div .="</a>";

		$div .='</div>';
		$k++;
}
$div .='</div>';
echo $div;
?>



</div>






</body>
</html>