<!DOCTYPE html>
<html>
<head>
	<title> Авторизация </title>
<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body style="font-family: Jura; align-content: center;">


<?php 
session_start();
 ?>


<header>
<a href="index.php"> <img src="img/logo.svg" class="logoimg" style="height: 60px;margin-top: -10px;"> </a>

</header>


<div class="loginbox">
	
<h1> Авторизация </h1>
<p></p>

<form action="test_user.php" method="post">

	<p>

		<input type="text" name="login" class="inputbar" placeholder="Логин...">
	</p>

	<p>
		<input type="password" name="password" class="inputbar" placeholder="Пароль...">
	</p>


<p>
	<input type="submit" name="submit" value="Войти" class="bigbutton">
</p>

</form>

<a href="register.php" style="font-size: 30px;"> Нет аккаунта ? Зарегистрируйтесть ! </a>



</div>



</body>
</html>