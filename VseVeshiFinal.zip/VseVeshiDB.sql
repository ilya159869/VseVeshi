-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 06 2024 г., 20:02
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `VseVeshiDB`
--

-- --------------------------------------------------------

--
-- Структура таблицы `remarks`
--

CREATE TABLE `remarks` (
  `comment_id` int NOT NULL,
  `commenter_login` varchar(60) NOT NULL,
  `saller_login` varchar(60) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `remarks`
--

INSERT INTO `remarks` (`comment_id`, `commenter_login`, `saller_login`, `comment_text`, `comment_time`) VALUES
(9, 'ilya159869', 'admin', 'когда будет новое поступление', '2024-05-06 15:29:59'),
(10, 'ilya159869', 'admin', 'доставка отличная и быстрая', '2024-05-06 15:30:16'),
(11, 'ilya159869', 'admin', 'потерялся заказ, продавец оперативно помог найти его номер на почте', '2024-05-06 15:33:09');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `fullname` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `login`, `password`, `email`, `address`, `fullname`, `phone`) VALUES
(7, 'danil', '12345', 'zloy.majestic@gmail.com', 'в луже живу', 'Петя', '+79777293391'),
(18, 'admin', '1', 'test@mail.ru', 'Улица пушкина дом колотушкина кв82', 'Админ Админович Админ', '+79777293391'),
(20, 'ilya159869', '12345', 'ilya@yaba.ru', 'Озёры улица пушкина дом колотушкина', 'Иванов Илья Викторович', '880053535');

-- --------------------------------------------------------

--
-- Структура таблицы `wares`
--

CREATE TABLE `wares` (
  `ware_id` int NOT NULL,
  `saller_login` varchar(60) NOT NULL,
  `ware_name` varchar(50) NOT NULL,
  `ware_type` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `cost` varchar(60) NOT NULL,
  `Upload_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ware_img` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `wares`
--

INSERT INTO `wares` (`ware_id`, `saller_login`, `ware_name`, `ware_type`, `description`, `cost`, `Upload_time`, `ware_img`) VALUES
(32, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png'),
(33, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png'),
(34, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png'),
(35, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png'),
(36, 'admin', 'пример товара без картинки', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.jpg'),
(37, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png'),
(38, 'admin', 'пример товара без картинки', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.jpg'),
(39, 'admin', 'пример товара', 'Литература', 'пример описание', '700', '2024-05-06 16:47:12', 'img/exampleware.png');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `remarks`
--
ALTER TABLE `remarks`
  ADD PRIMARY KEY (`comment_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `wares`
--
ALTER TABLE `wares`
  ADD PRIMARY KEY (`ware_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `remarks`
--
ALTER TABLE `remarks`
  MODIFY `comment_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `wares`
--
ALTER TABLE `wares`
  MODIFY `ware_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
